# lets-travel  

1. Clone this repository.  
2. Install dependencies.  
 $ npm install    
3. Start development server.  
 $ node app.js  
 
- This project was built by using HTML5, CSS3, Bootstrap 4 for the front-end part.  
- Node.js/ Express framework for the back-end API and MongoDB for the database were used.   
- The database is in the MongoDB Atlas remote cloud and front-end deployment took place in Heroku environment.  
